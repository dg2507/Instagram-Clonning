module.exports = {
    MONGOURI : "mongodb+srv://Instauser:TrTipthGt2FE9pHv@clusterinsta.tzokj.mongodb.net/<dbname>?retryWrites=true&w=majority",
    JWT_SECRET:"efgrhjskdhdhdhs3"
}